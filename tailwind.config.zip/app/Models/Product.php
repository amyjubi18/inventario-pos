<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class Product extends Model
{
    use HasFactory;
    protected $fillable = [
        'name',
        'description',
        'sku',
        'barcode',
        'price',
        'category_id',
        'stock'
    ];

    //Accesores
    protected function image(): Attribute {
        return Attribute::make(
            get: fn() => $this->images->count() ? Storage::url($this->images->first()->path) :  asset('img/no-image.jpeg')/* ? asset('storage/' . $this->images->first()->path) : asset('img/no-image.jpeg'), */
        );
    }
    //Relacion uno a muchos inversa

     public function category(){
        return $this->belongsTo(Category::class);
    }

    //Relacion uno a muchos inversa

     public function inventories(){
        return $this->hasMany(Inventory::class);
    }

    //Relacion muchos a muchos polimorfica
    public function purchaseOrders(){
        return $this->morphedByMany(PurchaseOrder::class, 'productable');
    }

    public function quotes(){
        return $this->morphedByMany(Quote::class, 'productable');
    }




    //Relacion polimorfica
    public function images(){
        return $this->morphMany(Image::class, 'imageable');
    }
}

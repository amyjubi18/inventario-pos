<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Maatwebsite\Excel\Events\AfterSheet;

class QuotesExport implements FromCollection, WithHeadings, WithStyles, ShouldAutoSize, WithEvents
{
    protected $quotes;
    public function __construct($quotes)
    {
        $this->quotes = $quotes;
    }
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return $this->quotes ->map(function($quote){
            return [
                $quote->id,
                $quote->date,
                $quote->serie,
                $quote->correlative,
                $quote->customer->identity->name,
                $quote->customer->document_number,
                $quote->customer->name,
                $quote->total,



            ];
        });
    }

    public function headings(): array
    {
        return [
            'id',
            'Fecha',
            'Serie',
            'Correlativo',
            'Proveedor (Identidad)',
            'N Documento',
            'Nombre del Proveedor',
            'Total',


        ];
    }

    public function styles(Worksheet $sheet)
    {
        $lastRow = $sheet->getHighestRow();
        $lastColumn = $sheet->getHighestColumn();

        $fullRange = 'A1:' . $lastColumn . $lastRow;
        return [
            1=>[
                    'font' => [
                        'bold' => true,
                        'size' => 14
                    ],
                    'fill' => [
                        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                        'startColor' => [
                            'argb' => 'FFCCCCCC',
                        ],
                    ],
                    'alignment' => [
                        'horizontal' =>'center',
                    ],
                ],
            $fullRange => [
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                            'color' => ['argb' => 'FF000000'],
                        ],
                    ],
                ],
        ];
    }
    public function registerEvents():  array
    {
        return [
            AfterSheet::class => function(AfterSheet $event) {
                $event->sheet->getDelegate()->setSelectedCell('A1');

            },
        ];
    }
}

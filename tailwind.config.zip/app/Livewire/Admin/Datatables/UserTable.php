<?php

namespace App\Livewire\Admin\Datatables;

use Rappasoft\LaravelLivewireTables\DataTableComponent;
use Rappasoft\LaravelLivewireTables\Views\Column;
use App\Models\User;

class UserTable extends DataTableComponent
{
    protected $model = User::class;

    public function configure(): void
    {
        $this->setPrimaryKey('id');
    }

    public function columns(): array
    {
        return [
            Column::make("Id", "id")
                ->sortable(),
            Column::make("Name", "name")
                ->sortable(),
            Column::make("Email", "email")
                ->sortable(),
            Column::make("Rol")
                ->label(function($row){
                    return $row->roles->first()->name ?? 'Sin rol';
                }),
            Column::make('Acciones')
            ->label(function($row){
                return view('admin.users.actions', [
                    'user' => $row,
                ]);
            })
        ];
    }
}

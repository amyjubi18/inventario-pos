<div class="flex items-center space-x-2">
    @can('read-products')


    <x-wire-button href="{{ route('admin.products.kardex', $product) }}" blue xs>
    <i class="fas fa-boxes-stacked "> </i></x-wire-button>
    @endcan
    @can('update-products')


    <x-wire-button href="{{ route('admin.products.edit', $product) }}" green xs>
    <i class="fas fa-edit "> </i></x-wire-button>
    @endcan
    @can('delete-products')
     <form action="{{ route('admin.products.destroy', $product) }}" method="post" class="delete-form">
        @csrf
        @method('DELETE')
        <x-wire-button type="submit" red xs>
        <i class="fas fa-trash-alt"> </i>
        </x-wire-button>
    </form>
    @endcan
</div>


<aside id="logo-sidebar" class="fixed top-0 left-0 z-40 w-64 h-screen pt-20 transition-transform -translate-x-full bg-white border-r border-gray-200 sm:translate-x-0 dark:bg-gray-800 dark:border-gray-700" aria-label="Sidebar">
   <div class="h-full px-3 pb-4 overflow-y-auto bg-white dark:bg-gray-800 dark:text-white">
      <ul class="space-y-2 font-medium">
        <?php $__currentLoopData = $itemsSidebar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <?php echo $link->render(); ?>

            </li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </ul>
   </div>
</aside>
<?php /**PATH C:\xampp\htdocs\inventario-pos\resources\views\layouts\includes\admin\sidebar.blade.php ENDPATH**/ ?>
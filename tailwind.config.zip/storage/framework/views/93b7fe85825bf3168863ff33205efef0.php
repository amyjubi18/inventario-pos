<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Dashboard | Inventario POS','breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
    [
        'name' => 'Dashboard',
        'href' => route('admin.dashboard')
    ],
    [
        'name' => 'Inicio',

    ],
])]); ?>
<div class="grid grid-cols-1 gap-6 mb-8 md:grid-cols-2 lg:grid-cols-4">
    <!-- Ventas del mes -->
    <?php if (isset($component)) { $__componentOriginal983a7eb9047f01311cddd82e78ab7d46 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal983a7eb9047f01311cddd82e78ab7d46 = $attributes; } ?>
<?php $component = WireUi\Components\Card\Index::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wire-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Components\Card\Index::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-white bg-gradient-to-r from-blue-500 to-blue-600']); ?>
        <div class="flex items-center justify-between">
            <div>
                <h3 class="text-lg font-semibold">Ventas del Mes</h3>
                <p class="text-2xl font-bold">S/. <?php echo e(number_format($salesThisMonth, 2)); ?></p>
            </div>
            <div class="text-4xl">
                <i class="fas fa-chart-line"></i>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal983a7eb9047f01311cddd82e78ab7d46)): ?>
<?php $attributes = $__attributesOriginal983a7eb9047f01311cddd82e78ab7d46; ?>
<?php unset($__attributesOriginal983a7eb9047f01311cddd82e78ab7d46); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal983a7eb9047f01311cddd82e78ab7d46)): ?>
<?php $component = $__componentOriginal983a7eb9047f01311cddd82e78ab7d46; ?>
<?php unset($__componentOriginal983a7eb9047f01311cddd82e78ab7d46); ?>
<?php endif; ?>

    <!-- Compras del mes -->
    <?php if (isset($component)) { $__componentOriginal983a7eb9047f01311cddd82e78ab7d46 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal983a7eb9047f01311cddd82e78ab7d46 = $attributes; } ?>
<?php $component = WireUi\Components\Card\Index::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wire-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Components\Card\Index::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-white bg-gradient-to-r from-green-500 to-green-600']); ?>
        <div class="flex items-center justify-between">
            <div>
                <h3 class="text-lg font-semibold">Compras del Mes</h3>
                <p class="text-2xl font-bold">S/. <?php echo e(number_format($purchasesThisMonth, 2)); ?></p>
            </div>
            <div class="text-4xl">
                <i class="fas fa-shopping-cart"></i>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal983a7eb9047f01311cddd82e78ab7d46)): ?>
<?php $attributes = $__attributesOriginal983a7eb9047f01311cddd82e78ab7d46; ?>
<?php unset($__attributesOriginal983a7eb9047f01311cddd82e78ab7d46); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal983a7eb9047f01311cddd82e78ab7d46)): ?>
<?php $component = $__componentOriginal983a7eb9047f01311cddd82e78ab7d46; ?>
<?php unset($__componentOriginal983a7eb9047f01311cddd82e78ab7d46); ?>
<?php endif; ?>

    <!-- Productos registrados -->
    <?php if (isset($component)) { $__componentOriginal983a7eb9047f01311cddd82e78ab7d46 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal983a7eb9047f01311cddd82e78ab7d46 = $attributes; } ?>
<?php $component = WireUi\Components\Card\Index::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wire-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Components\Card\Index::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-white bg-gradient-to-r from-purple-500 to-purple-600']); ?>
        <div class="flex items-center justify-between">
            <div>
                <h3 class="text-lg font-semibold">Productos</h3>
                <p class="text-2xl font-bold"><?php echo e(number_format($totalProducts)); ?></p>
            </div>
            <div class="text-4xl">
                <i class="fas fa-box"></i>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal983a7eb9047f01311cddd82e78ab7d46)): ?>
<?php $attributes = $__attributesOriginal983a7eb9047f01311cddd82e78ab7d46; ?>
<?php unset($__attributesOriginal983a7eb9047f01311cddd82e78ab7d46); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal983a7eb9047f01311cddd82e78ab7d46)): ?>
<?php $component = $__componentOriginal983a7eb9047f01311cddd82e78ab7d46; ?>
<?php unset($__componentOriginal983a7eb9047f01311cddd82e78ab7d46); ?>
<?php endif; ?>

    <!-- Stock total -->
    <?php if (isset($component)) { $__componentOriginal983a7eb9047f01311cddd82e78ab7d46 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal983a7eb9047f01311cddd82e78ab7d46 = $attributes; } ?>
<?php $component = WireUi\Components\Card\Index::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wire-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Components\Card\Index::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-white bg-gradient-to-r from-orange-500 to-orange-600']); ?>
        <div class="flex items-center justify-between">
            <div>
                <h3 class="text-lg font-semibold">Stock Total</h3>
                <p class="text-2xl font-bold"><?php echo e(number_format($totalStock)); ?></p>
            </div>
            <div class="text-4xl">
                <i class="fas fa-warehouse"></i>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal983a7eb9047f01311cddd82e78ab7d46)): ?>
<?php $attributes = $__attributesOriginal983a7eb9047f01311cddd82e78ab7d46; ?>
<?php unset($__attributesOriginal983a7eb9047f01311cddd82e78ab7d46); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal983a7eb9047f01311cddd82e78ab7d46)): ?>
<?php $component = $__componentOriginal983a7eb9047f01311cddd82e78ab7d46; ?>
<?php unset($__componentOriginal983a7eb9047f01311cddd82e78ab7d46); ?>
<?php endif; ?>


</div>

<div class="grid grid-cols-1 gap-6 mb-8 lg:grid-cols-2">
    <!-- Gráfica de ventas por día -->
    <?php if (isset($component)) { $__componentOriginal983a7eb9047f01311cddd82e78ab7d46 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal983a7eb9047f01311cddd82e78ab7d46 = $attributes; } ?>
<?php $component = WireUi\Components\Card\Index::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wire-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Components\Card\Index::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'dark:bg-gray-800 dark:text-white']); ?>
        <h3 class="mb-4 text-lg font-semibold">Ventas por Día </h3>
        <div id="sales-chart" class="w-full h-64"></div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal983a7eb9047f01311cddd82e78ab7d46)): ?>
<?php $attributes = $__attributesOriginal983a7eb9047f01311cddd82e78ab7d46; ?>
<?php unset($__attributesOriginal983a7eb9047f01311cddd82e78ab7d46); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal983a7eb9047f01311cddd82e78ab7d46)): ?>
<?php $component = $__componentOriginal983a7eb9047f01311cddd82e78ab7d46; ?>
<?php unset($__componentOriginal983a7eb9047f01311cddd82e78ab7d46); ?>
<?php endif; ?>

    <!-- Gráfica de top productos -->
    <?php if (isset($component)) { $__componentOriginal983a7eb9047f01311cddd82e78ab7d46 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal983a7eb9047f01311cddd82e78ab7d46 = $attributes; } ?>
<?php $component = WireUi\Components\Card\Index::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wire-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Components\Card\Index::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'dark:bg-gray-800 dark:text-white']); ?>
        <h3 class="mb-4 text-lg font-semibold">Top 5 Productos Más Vendidos</h3>
        <div id="top-products-chart" class="w-full h-64"></div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal983a7eb9047f01311cddd82e78ab7d46)): ?>
<?php $attributes = $__attributesOriginal983a7eb9047f01311cddd82e78ab7d46; ?>
<?php unset($__attributesOriginal983a7eb9047f01311cddd82e78ab7d46); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal983a7eb9047f01311cddd82e78ab7d46)): ?>
<?php $component = $__componentOriginal983a7eb9047f01311cddd82e78ab7d46; ?>
<?php unset($__componentOriginal983a7eb9047f01311cddd82e78ab7d46); ?>
<?php endif; ?>
</div>

<script>
    window.salesByDay = <?php echo json_encode($salesByDay, 15, 512) ?>;
    window.topProducts = <?php echo json_encode($topProducts, 15, 512) ?>;
    window.shoppingCartsByDay = <?php echo json_encode($shoppingCartsByDay, 15, 512) ?>;
    window.topProductsShopping = <?php echo json_encode($topProductsShopping, 15, 512) ?>;
</script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Function to get current theme
    const getCurrentTheme = () => {
        return document.documentElement.classList.contains('dark') ? 'dark' : 'light';
    };

    // Gráfica de ventas por día
    const salesData = <?php echo json_encode($salesByDay, 15, 512) ?>;
    const salesOptions = {
        series: [{
            name: 'Ventas',
            data: Object.values(salesData)
        }],
        chart: {
            type: 'bar',
            height: 250,
            toolbar: {
                show: false
            },
            background: 'transparent'
        },
        theme: {
            mode: getCurrentTheme()
        },
        xaxis: {
            categories: Object.keys(salesData).map(date => new Date(date).toLocaleDateString('es-ES', { month: 'short', day: 'numeric' })),
            labels: {
                style: {
                    colors: getCurrentTheme() === 'dark' ? '#9CA3AF' : '#374151'
                }
            }
        },
        yaxis: {
            labels: {
                style: {
                    colors: getCurrentTheme() === 'dark' ? '#9CA3AF' : '#374151'
                }
            }
        },
        colors: ['#3B82F6'], // Azul
        plotOptions: {
            bar: {
                borderRadius: 4,
                columnWidth: '60%'
            }
        },
        grid: {
            borderColor: getCurrentTheme() === 'dark' ? '#374151' : '#E5E7EB'
        }
    };
    const salesChart = new ApexCharts(document.querySelector("#sales-chart"), salesOptions);
    salesChart.render();

    // Gráfica de top productos
    const topProductsData = <?php echo json_encode($topProducts, 15, 512) ?>;
    const topProductsOptions = {
        series: [{
            name: 'Cantidad Vendida',
            data: topProductsData.map(item => item.total_quantity)
        }],
        chart: {
            type: 'bar',
            height: 250,
            toolbar: {
                show: false
            },
            background: 'transparent'
        },
        theme: {
            mode: getCurrentTheme()
        },
        xaxis: {
            categories: topProductsData.map(item => item.name.length > 15 ? item.name.substring(0, 15) + '...' : item.name),
            labels: {
                style: {
                    colors: getCurrentTheme() === 'dark' ? '#9CA3AF' : '#374151'
                }
            }
        },
        yaxis: {
            labels: {
                style: {
                    colors: getCurrentTheme() === 'dark' ? '#9CA3AF' : '#374151'
                }
            }
        },
        colors: ['#10B981'], // Verde
        plotOptions: {
            bar: {
                borderRadius: 4,
                columnWidth: '60%'
            }
        },
        grid: {
            borderColor: getCurrentTheme() === 'dark' ? '#374151' : '#E5E7EB'
        }
    };
    const topProductsChart = new ApexCharts(document.querySelector("#top-products-chart"), topProductsOptions);
    topProductsChart.render();

    // Gráfica de shopping carts por día
    const shoppingCartsData = <?php echo json_encode($shoppingCartsByDay, 15, 512) ?>;
    const shoppingCartsOptions = {
        series: [{
            name: 'Shopping Carts',
            data: Object.values(shoppingCartsData)
        }],
        chart: {
            type: 'bar',
            height: 250,
            toolbar: {
                show: false
            },
            background: 'transparent'
        },
        theme: {
            mode: getCurrentTheme()
        },
        xaxis: {
            categories: Object.keys(shoppingCartsData).map(date => new Date(date).toLocaleDateString('es-ES', { month: 'short', day: 'numeric' })),
            labels: {
                style: {
                    colors: getCurrentTheme() === 'dark' ? '#9CA3AF' : '#374151'
                }
            }
        },
        yaxis: {
            labels: {
                style: {
                    colors: getCurrentTheme() === 'dark' ? '#9CA3AF' : '#374151'
                }
            }
        },
        colors: ['#3B82F6'], // Azul
        plotOptions: {
            bar: {
                borderRadius: 4,
                columnWidth: '60%'
            }
        },
        grid: {
            borderColor: getCurrentTheme() === 'dark' ? '#374151' : '#E5E7EB'
        }
    };
    const shoppingCartsChart = new ApexCharts(document.querySelector("#shopping-carts-chart"), shoppingCartsOptions);
    shoppingCartsChart.render();

    // Gráfica de top productos en shopping carts
    const topProductsShoppingData = <?php echo json_encode($topProductsShopping, 15, 512) ?>;
    const topProductsShoppingOptions = {
        series: [{
            name: 'Cantidad Vendida',
            data: topProductsShoppingData.map(item => item.total_quantity)
        }],
        chart: {
            type: 'bar',
            height: 250,
            toolbar: {
                show: false
            },
            background: 'transparent'
        },
        theme: {
            mode: getCurrentTheme()
        },
        xaxis: {
            categories: topProductsShoppingData.map(item => item.name.length > 15 ? item.name.substring(0, 15) + '...' : item.name),
            labels: {
                style: {
                    colors: getCurrentTheme() === 'dark' ? '#9CA3AF' : '#374151'
                }
            }
        },
        yaxis: {
            labels: {
                style: {
                    colors: getCurrentTheme() === 'dark' ? '#9CA3AF' : '#374151'
                }
            }
        },
        colors: ['#10B981'], // Verde
        plotOptions: {
            bar: {
                borderRadius: 4,
                columnWidth: '60%'
            }
        },
        grid: {
            borderColor: getCurrentTheme() === 'dark' ? '#374151' : '#E5E7EB'
        }
    };
    const topProductsShoppingChart = new ApexCharts(document.querySelector("#top-products-shopping-chart"), topProductsShoppingOptions);
    topProductsShoppingChart.render();

    // Listen for theme changes
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.attributeName === 'class') {
                const newTheme = getCurrentTheme();
                salesChart.updateOptions({
                    theme: { mode: newTheme },
                    xaxis: {
                        labels: {
                            style: {
                                colors: newTheme === 'dark' ? '#9CA3AF' : '#374151'
                            }
                        }
                    },
                    yaxis: {
                        labels: {
                            style: {
                                colors: newTheme === 'dark' ? '#9CA3AF' : '#374151'
                            }
                        }
                    },
                    grid: {
                        borderColor: newTheme === 'dark' ? '#374151' : '#E5E7EB'
                    }
                });
                topProductsChart.updateOptions({
                    theme: { mode: newTheme },
                    xaxis: {
                        labels: {
                            style: {
                                colors: newTheme === 'dark' ? '#9CA3AF' : '#374151'
                            }
                        }
                    },
                    yaxis: {
                        labels: {
                            style: {
                                colors: newTheme === 'dark' ? '#9CA3AF' : '#374151'
                            }
                        }
                    },
                    grid: {
                        borderColor: newTheme === 'dark' ? '#374151' : '#E5E7EB'
                    }
                });
                shoppingCartsChart.updateOptions({
                    theme: { mode: newTheme },
                    xaxis: {
                        labels: {
                            style: {
                                colors: newTheme === 'dark' ? '#9CA3AF' : '#374151'
                            }
                        }
                    },
                    yaxis: {
                        labels: {
                            style: {
                                colors: newTheme === 'dark' ? '#9CA3AF' : '#374151'
                            }
                        }
                    },
                    grid: {
                        borderColor: newTheme === 'dark' ? '#374151' : '#E5E7EB'
                    }
                });
                topProductsShoppingChart.updateOptions({
                    theme: { mode: newTheme },
                    xaxis: {
                        labels: {
                            style: {
                                colors: newTheme === 'dark' ? '#9CA3AF' : '#374151'
                            }
                        }
                    },
                    yaxis: {
                        labels: {
                            style: {
                                colors: newTheme === 'dark' ? '#9CA3AF' : '#374151'
                            }
                        }
                    },
                    grid: {
                        borderColor: newTheme === 'dark' ? '#374151' : '#E5E7EB'
                    }
                });
            }
        });
    });

    observer.observe(document.documentElement, {
        attributes: true,
        attributeFilter: ['class']
    });
});
</script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\inventario-pos\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
<button wire:click="showStock(<?php echo e($product->id); ?>)">
    <?php echo e($stock); ?>

</button>
<?php /**PATH C:\xampp\htdocs\inventario-pos\resources\views\admin\products\stock.blade.php ENDPATH**/ ?>
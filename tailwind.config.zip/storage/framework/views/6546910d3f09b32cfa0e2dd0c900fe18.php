<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => config('app.name', 'Laravel'),
    'breadcrumbs' => []
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => config('app.name', 'Laravel'),
    'breadcrumbs' => []
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e($title); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />




        
        <script src="https://kit.fontawesome.com/6be0f5c987.js" crossorigin="anonymous"></script>

        
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

        
        <script >window.Wireui = {cache: {},hook(hook, callback) {window.addEventListener(`wireui:${hook}`, () => callback())},dispatchHook(hook) {window.dispatchEvent(new Event(`wireui:${hook}`))}}</script>
<script src="http://inventario-pos.test/wireui/assets/scripts" defer ></script>

        
        <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(entrypoints: ['resources/css/app.css', 'resources/js/app.js']); ?>

        
        <script>
            // On page load or when changing themes, best to add inline in `head` to avoid FOUC
            if (!localStorage.getItem('color-theme')) {
                localStorage.setItem('color-theme', 'light');
            }
            if (localStorage.getItem('color-theme') === 'dark') {

            document.addEventListener('DOMContentLoaded', function() {
                const themeToggleDarkIcon = document.getElementById('theme-toggle-dark-icon');
                const themeToggleLightIcon = document.getElementById('theme-toggle-light-icon');
                const themeToggleBtn = document.getElementById('theme-toggle');

                // Function to set the theme and update icons
                function applyTheme() {
                    const userTheme = localStorage.getItem('color-theme');
                    if (userTheme === 'dark') {
                        // Dark mode: show moon, hide sun
                        if (themeToggleLightIcon) themeToggleLightIcon.classList.add('hidden');
                        if (themeToggleDarkIcon) themeToggleDarkIcon.classList.remove('hidden');
                        document.documentElement.classList.add('dark');
                    } else {
                        // Light mode: show sun, hide moon
                        if (themeToggleDarkIcon) themeToggleDarkIcon.classList.add('hidden');
                        if (themeToggleLightIcon) themeToggleLightIcon.classList.remove('hidden');
                        document.documentElement.classList.remove('dark');
                    }
                }

                // Apply the theme on initial load
                applyTheme();

                if (themeToggleBtn) {
                    themeToggleBtn.addEventListener('click', function() {
                        // Toggle theme
                        const current = localStorage.getItem('color-theme');
                        if (current === 'dark') {
                            localStorage.setItem('color-theme', 'light');
                        } else {
                            localStorage.setItem('color-theme', 'dark');
                        }
                        applyTheme();
                    });
                }
            });
        </script>


        <!-- Styles -->
        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

        <?php echo $__env->yieldPushContent('css'); ?>
    </head>
    <body class="font-sans antialiased dark:bg-gray-700">

<?php echo $__env->make('layouts.includes.admin.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('layouts.includes.admin.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>




<div class="h-full p-4 bg-gray-50 sm:ml-64 dark:bg-gray-500">
   <div class="flex items-center mt-14">
        <?php echo $__env->make('layouts.includes.admin.breadcrumb', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php if(isset($action)): ?>
        <div class="ml-auto">
            <?php echo e($action); ?>

        </div>

        <?php endif; ?>
   </div>



   <?php echo e($slot); ?>

</div>


        <?php echo $__env->yieldPushContent('modals'); ?>

        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

            <script src="https://cdn.jsdelivr.net/npm/flowbite@3.1.2/dist/flowbite.min.js"></script>

            <script>
                Livewire.on('swal', (data) => {
                    Swal.fire(data[0]);
                })
            </script>

            <?php if(session('swal')): ?>
            <script>
                Swal.fire(<?php echo json_encode(session('swal'), 15, 512) ?>);
            </script>
            <?php endif; ?>

    <script>
        forms = document.querySelectorAll('.delete-form');
        forms.forEach(form => {
            form.addEventListener('submit', function(e) {
                e.preventDefault();

                //alert('Se detuvo el envio del formulario');
                Swal.fire({
                    title: 'Estas seguro?',
                    text: "No podras revertir esto!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Si, eliminar!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.submit();
                    }
                })
            });
        });

    </script>

            <?php echo $__env->yieldPushContent('js'); ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\inventario-pos\resources\views/layouts/admin.blade.php ENDPATH**/ ?>

<?php if (isset($component)) { $__componentOriginalf5a0c2336b430c2ccbe7b96a08cb0ba9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf5a0c2336b430c2ccbe7b96a08cb0ba9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal-card','data' => ['title' => 'Stock por Almacen','wire:model' => 'openModal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Stock por Almacen','wire:model' => 'openModal']); ?>
    <ul class="space-y-3">
        <?php $__empty_1 = true; $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li class="flex items-center justify-between p-4 mb-2 bg-gray-100 rounded-lg shadow-sm">
                <div >
                    <p class="text-sm text-gray-600">
                        <?php echo e($inventory->warehouse->name); ?>:
                    </p>
                    <p class="font-medium text-gray-800">
                        <?php echo e($inventory->warehouse->location); ?>


                    </p>
                </div>
                <div class="text-right">
                    <p class="text-sm text-gray-500">
                        Stock Disponible
                    </p>
                    <p class="text-lg font-bold <?php echo e($inventory->quantity_balance > 0 ? 'text-green-600' : 'text-red-600'); ?>">
                        <?php echo e($inventory->quantity_balance); ?>

                    </p>

                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <li class="py-10 text-center text-gray-500">
                No hay inventarios disponibles.
            </li>
        <?php endif; ?>
    </ul>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf5a0c2336b430c2ccbe7b96a08cb0ba9)): ?>
<?php $attributes = $__attributesOriginalf5a0c2336b430c2ccbe7b96a08cb0ba9; ?>
<?php unset($__attributesOriginalf5a0c2336b430c2ccbe7b96a08cb0ba9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf5a0c2336b430c2ccbe7b96a08cb0ba9)): ?>
<?php $component = $__componentOriginalf5a0c2336b430c2ccbe7b96a08cb0ba9; ?>
<?php unset($__componentOriginalf5a0c2336b430c2ccbe7b96a08cb0ba9); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\inventario-pos\resources\views\admin\products\modal.blade.php ENDPATH**/ ?>
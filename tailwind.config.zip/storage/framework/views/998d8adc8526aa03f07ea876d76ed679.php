<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Detalle de la Orden de Compra</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            margin: 20px;
        }
        .titlle{
            text-align: center;
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 6px 8px;
            text-align: left;
        }
        th {
            background-color: #f0f0f0;
        }
        .section{
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="titlle">
        Detalle de la Orden de Compra #<?php echo e($model->serie); ?> - <?php echo e(str_pad($model->correlative, 4, '0', STR_PAD_LEFT)); ?>

    </div>
    <div>
        <strong>Fecha:</strong> <?php echo e(\Carbon\Carbon::parse($model->date)->format('d/m/Y')); ?> <br>
        <strong>Proveedor:</strong> <?php echo e($model->supplier->name ?? '-'); ?> <br>
        <strong>Observacion:</strong> <?php echo e($model->observation ?? '-'); ?> <br>
    </div>
    <div class="section">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Producto</th>
                    <th>Cantidad</th>
                    <th>Precio Unitario</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $model->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i + 1); ?></td>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($product->pivot->quantity); ?></td>
                    <td>S/ <?php echo e(number_format($product->pivot->price, 2)); ?></td>
                    <td>S/ <?php echo e(number_format($product->pivot->subtotal, 2)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="section" style="text-align: right;">
        <strong>Total: </strong> S/ <?php echo e(number_format($model->total, 2)); ?>

    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\inventario-pos\resources\views\admin\purchase_orders\pdf.blade.php ENDPATH**/ ?>
<?php $__env->startComponent('mail::message'); ?>
# <?php echo e($form['document']); ?>


Se ha generado un nuevo documento y se ha enviado a su correo electrónico.
<br>
Gracias por confiar en nosotros.<br>
<b><?php echo e(config('app.name')); ?></b>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\inventario-pos\resources\views\emails\pdf-send.blade.php ENDPATH**/ ?>